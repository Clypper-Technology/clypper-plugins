<?php

namespace ClypperTechnology\ClypperCvr\includes;

defined( 'ABSPATH' ) || exit;

class Admin
{
    public function __construct()
    {
        add_filter( 'manage_users_columns', array( $this, 'add_cvr_column' ) );
        add_action( 'manage_users_custom_column', array( $this, 'show_cvr_column_content' ), 10, 3 );
        add_action( 'show_user_profile', array( $this, 'show_custom_customer_fields' ) );
        add_action( 'edit_user_profile', array( $this, 'show_custom_customer_fields' ) );
    }

    public function show_custom_customer_fields( $user ): void {
        $company_name = get_user_meta( $user->ID, 'company_name', true );
        $company_cvr = get_user_meta( $user->ID, 'company_cvr', true );
        $company_type = get_user_meta( $user->ID, 'company_type', true );

        // Only show if user has company information
        if ( $company_name || $company_cvr || $company_type ) {
            ?>
            <h3><?php _e( 'Virksomhedsoplysninger', 'woo-roles-rules-b2b' ); ?></h3>
            <table class="form-table">
                <?php if ( $company_name ) : ?>
                    <tr>
                        <th><label><?php _e( 'Virksomhedsnavn', 'woo-roles-rules-b2b' ); ?></label></th>
                        <td><?php echo esc_html( $company_name ); ?></td>
                    </tr>
                <?php endif; ?>

                <?php if ( $company_cvr ) : ?>
                    <tr>
                        <th><label><?php _e( 'CVR Nummer', 'woo-roles-rules-b2b' ); ?></label></th>
                        <td><?php echo esc_html( $company_cvr ); ?></td>
                    </tr>
                <?php endif; ?>

                <?php if ( $company_type ) : ?>
                    <tr>
                        <th><label><?php _e( 'Industri', 'woo-roles-rules-b2b' ); ?></label></th>
                        <td><?php echo esc_html( $company_type ); ?></td>
                    </tr>
                <?php endif; ?>
            </table>
            <?php
        }
    }

    public function add_cvr_column( $columns ) {
        $columns['company_cvr'] = __( 'CVR', 'woo-roles-rules-b2b' );
        return $columns;
    }

    public function show_cvr_column_content( $value, $column_name, $user_id ) {
        if ( $column_name === 'company_cvr' ) {
            return get_user_meta( $user_id, 'company_cvr', true );
        }
        return $value;
    }
}